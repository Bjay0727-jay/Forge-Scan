# ForgeScan Design & Configuration Package

Complete design and configuration for the ForgeScan 360 engine.
All files are organized to match the existing Forge-Scan repo structure.

## File Inventory

### Engine Core
| File | Drop Into | Purpose |
|------|-----------|---------|
| `engine/Cargo.toml` | `engine/Cargo.toml` | Workspace config with all 10 crates, workspace deps, release profiles |
| `engine/CRATE-CONFIGS.toml` | Split into individual `Cargo.toml` files per crate | Dependency definitions for all 10 crates |
| `engine/config/scanner.toml` | `engine/config/scanner.toml` | **Full scanner configuration** — targets, ports, discovery, vulns, checks, config audit, webapp, cloud, reporting, scheduling, notifications, resource limits, logging |
| `engine/config/agent.toml` | `engine/config/agent.toml` | **Full agent configuration** — platform connectivity, local inspection, FIM, compliance checks, log collection, security, auto-update |

### gRPC Protocol
| File | Drop Into | Purpose |
|------|-----------|---------|
| `engine/proto/scan.proto` | `engine/proto/scan.proto` | **Complete Protocol Buffer definitions** — 3 services (Scanner, Command, Agent), 30+ message types, finding streaming, scan management, agent inventory/compliance reporting |

### Check Definitions (24 checks)
| File | Drop Into | Purpose |
|------|-----------|---------|
| `engine/checks/CHECK-FORMAT.yaml` | `engine/checks/` | Format specification reference |
| `engine/checks/vulnerability/FSC-VULN-0001-log4shell.yaml` | `engine/checks/vulnerability/` | Log4Shell (CVE-2021-44228) with JNDI injection detection |
| `engine/checks/vulnerability/FSC-VULN-0002-to-0012.yaml` | Split into individual files | OpenSSH regreSSHion, SMBv1/EternalBlue, SSL/TLS cert expired, TLS 1.0/1.1, self-signed cert |
| `engine/checks/configuration/FSC-CFG-0001-to-0010.yaml` | Split into individual files | SSH root login, password auth, firewall disabled, audit logging, disk encryption, screen lock, password complexity |
| `engine/checks/network/FSC-NET-0001-to-0006.yaml` | Split into individual files | Default credentials, telnet exposed, FTP cleartext, SNMP defaults, database exposed, RDP exposed |

### Deployment
| File | Drop Into | Purpose |
|------|-----------|---------|
| `deploy/Dockerfile.scanner` | `deploy/Dockerfile.scanner` | Multi-stage Docker build (Rust builder → minimal Debian runtime) |
| `deploy/ci.yml` | `.github/workflows/ci.yml` | Full CI pipeline: check/lint → test → build (x64+arm64) → Docker |

## Integration Steps

### 1. Workspace Config
```bash
# Replace existing Cargo.toml with the workspace version
cp engine/Cargo.toml /path/to/Forge-Scan/engine/Cargo.toml

# Split CRATE-CONFIGS.toml into individual Cargo.toml files
# (each section is clearly labeled with the target path)
```

### 2. Scanner Config
```bash
cp engine/config/scanner.toml /path/to/Forge-Scan/engine/config/scanner.example.toml
cp engine/config/agent.toml /path/to/Forge-Scan/engine/config/agent.example.toml
```

### 3. gRPC Proto
```bash
cp engine/proto/scan.proto /path/to/Forge-Scan/engine/proto/scan.proto
# Add build.rs to forgescan-scanner and forgescan-agent crates:
# tonic_build::compile_protos("../../proto/scan.proto").unwrap();
```

### 4. Check Definitions
```bash
cp -r engine/checks/ /path/to/Forge-Scan/engine/checks/
# Split multi-check YAML files into individual files (one check per file)
```

### 5. CI/CD
```bash
cp deploy/ci.yml /path/to/Forge-Scan/.github/workflows/ci.yml
```

### 6. Docker
```bash
cp deploy/Dockerfile.scanner /path/to/Forge-Scan/deploy/Dockerfile.scanner
docker build -t forgescan-scanner -f deploy/Dockerfile.scanner .
```

## MVP Priority: What to Build First

The scanner MVP needs these crates functional (in order):

1. **forgescan-core** — Types, traits, errors. Must compile clean.
2. **forgescan-common** — Config parser (reads scanner.toml), logger setup.
3. **forgescan-checks** — YAML parser that loads check definitions from disk.
4. **forgescan-network** — Host discovery (ping/ARP/TCP SYN) + port scanning + service detection + banner grabbing.
5. **forgescan-nvd** — SQLite-based NVD database with CPE-to-CVE lookup.
6. **forgescan-vuln** — Version matching engine that correlates discovered services against NVD data.
7. **forgescan-scanner** — The binary that composes all of the above into a scan pipeline.

**Defer for now:** forgescan-webapp, forgescan-cloud, forgescan-agent.

## Check Definition Count

| Category | Checks | Priority |
|----------|--------|----------|
| Vulnerability (version-match) | 6 | MVP |
| Configuration (config/command-check) | 7 | MVP |
| Network (port/banner-check) | 6 | MVP |
| Web Application | 0 (defer) | Phase 2 |
| Cloud | 0 (defer) | Phase 2 |
| **Total** | **19 MVP + format spec** | |

Each check includes NIST 800-53 control mappings and HIPAA references
where applicable, connecting scanner findings directly to compliance requirements
tracked in ForgeComply 360.
